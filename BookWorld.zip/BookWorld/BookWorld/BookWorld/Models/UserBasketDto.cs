﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookWorld.Models
{
    public class UserBasketDto
    {

        public int BookId { get; set; }

        public int Number { get; set; }
        public string UserId { get; set; }
        
    }
}
